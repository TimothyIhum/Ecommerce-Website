<html>
<head>
   <style>
       body{
           font-family: 'Franklin Gothic Medium';
  text-align: center;
          background: linear-gradient(to right, Blue, Yellow);  }
       }
    </style>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <h1>Welcome to our website</h1>
    <?php
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){
    $conn= mysqli_connect('localhost', 'root', '', 'sign_form') or die("Connection failed:". mysqli_connect_error());
    if(isset($_POST['firstname']) &&isset($_POST['lastname']) &&isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])){
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];    
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password']; 
            
    $sql = "INSERT INTO `user` (`firstname`, `lastname`, `username`, `email`, `password`) VALUES('$firstname', '$lastname', '$username', '$email', '$password')";
        
    $query = mysqli_query($conn,$sql);  
        
    if($query){
        echo 'Registration successful';
        }    
        
    else{
        echo 'There is an error with details';
        }    
    }        
}
?>
<br>
    <h3> Click to be <a href="Index.html">redirected</a></h3>
</body>
</html>
