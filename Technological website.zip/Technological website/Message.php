<html>
<head>
   <style>
       body{
           font-family: 'Franklin Gothic Medium';
  text-align: center;
          background: linear-gradient(to right, Blue, Yellow);  }
       
    </style>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <h1>Welcome to our website</h1>
  <?php
if ($_POST) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $dbname = "contact_form";
    $con = mysqli_connect("localhost","root", "",'contact_form');
    
    $sql = "INSERT INTO `usb` (`username`, `email`, `message`) VALUES('$username', '$email', '$message')";
        
    $query = mysqli_query($con,$sql);  
        
    if($query){
        echo  $username , " your message was sent";
        }    
        
    else{
        echo 'There is an error with details';
        }    
    }       
?>
  <br>
    <h3> Click to be <a href="Index.html">redirected</a></h3>
    
</body>
</html>  