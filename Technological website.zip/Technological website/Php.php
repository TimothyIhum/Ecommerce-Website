<?php

if ($_POST){
    
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $dbname = "teaching_form";
    
    $connection = mysqli_connect("localhost", "root", "", 'teaching_form');
    
    $sql = "INSERT into `teacher_users`(`username`, `email`, `password`) VALUES ('$username', '$email', '$password')";
    
    $query = mysqli_query($connection, $sql);
    
    if ($query){
        echo $username, " you have successfully synced into your profile <br> and your emails have been renewed";
    }
    else{
        echo "There was an error with details";
    }
}
    
?>